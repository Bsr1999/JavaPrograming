package com.sortingUtil;

import java.util.List;

import com.sortingUtil.algorithm.BubbleSort;

public class MySortingUtil {
	public List<String> sort(List<String> names){
		BubbleSort bubbleSort=new BubbleSort();
		return bubbleSort.sort(names);
	}

}
