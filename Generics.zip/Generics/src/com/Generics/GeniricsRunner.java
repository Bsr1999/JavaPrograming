package com.Generics;

public class GeniricsRunner {
	public static void main(String[] args) {
		MyCustomList<Long> list=new MyCustomList<>();
		list.addElement(5l);
		list.addElement(7l);
		long value =list.get(0);
		System.out.println(value);
		MyCustomList<Integer> list2=new MyCustomList<>();
		list2.addElement(Integer.valueOf(5));
		list2.addElement(Integer.valueOf(8));
		Integer number =list2.get(0);
		System.out.println(number);
		
	}

}
