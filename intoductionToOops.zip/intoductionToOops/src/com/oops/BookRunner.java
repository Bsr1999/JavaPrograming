package com.oops;

public class BookRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book bhanu = new Book(1000);
		Book chandu = new Book(2000);
		Book sri = new Book(1000);
		System.out.println(bhanu.getNoOfCopies());

		System.out.println(chandu.getNoOfCopies());
		System.out.println(sri.getNoOfCopies());
		bhanu.setNoOfCopies(99);
		chandu.setNoOfCopies(98);
		sri.setNoOfCopies(10);
		bhanu.increaseNoOfCopies(900);
		chandu.increaseNoOfCopies(700);
		sri.increaseNoOfCopies(600);
		System.out.println(bhanu.getNoOfCopies());

		System.out.println(chandu.getNoOfCopies());
		System.out.println(sri.getNoOfCopies());

	}

}
