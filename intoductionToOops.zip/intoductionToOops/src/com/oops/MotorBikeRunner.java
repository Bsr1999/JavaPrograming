package com.oops;

public class MotorBikeRunner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MotorBike Honda = new MotorBike(100);
		MotorBike Ducati = new MotorBike(200);

		System.out.println(Honda.getSpeed());

		System.out.println(Ducati.getSpeed());
		Honda.start();
		Honda.setSpeed(100);
		Honda.increaseSpeed(100);
		Ducati.increaseSpeed(90);
		Honda.decreaseSpeed(200);
		Ducati.decreaseSpeed(290);

		System.out.println(Honda.getSpeed());

		System.out.println(Ducati.getSpeed());

	}

}
