package com.oops;

public class Book {

	private int noOfCopies;

	Book(int noOfCopies) {
		this.noOfCopies = noOfCopies;
	}

	public int getNoOfCopies() {
		return noOfCopies;
	}

	public void setNoOfCopies(int noOfCopies) {
		if (noOfCopies > 0)
			this.noOfCopies = noOfCopies;
	}

	public void increaseNoOfCopies(int howMuch) {
		this.noOfCopies = noOfCopies + howMuch;
	}

	public void decreaseNoOfCopies(int howMuch) {
		this.noOfCopies = noOfCopies - howMuch;
	}

	void read() {
		System.out.println("read book");

	}
}
