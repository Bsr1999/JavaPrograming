package objectOrientation;

public class CustomerRunner {

	public static void main(String[] args) {

		Address homeAddress = new Address("line 1", "Hyderadad", "500035");

		Customer customer = new Customer("Bhanu", homeAddress);
		Address workAddress = new Address("line 1 for work", "Hyderadad", "500078");

		customer.setWorkAddress(workAddress);
		System.out.println(customer);

	}

}
