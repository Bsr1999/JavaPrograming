package objectOrientation;

public class RectangularRunner {
	public static void main(String[] args) {

		// TODO Auto-generated constructor stub
		Rectangle rectangle = new Rectangle(12, 14);
		System.out.println(rectangle);
		rectangle.setWidth(25);
		System.out.println(rectangle);
	}

}
