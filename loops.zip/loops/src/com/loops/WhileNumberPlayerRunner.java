package com.loops;

public class WhileNumberPlayerRunner {
	public static void main(String[] args) {
		WhileNumberPlayer player = new WhileNumberPlayer(30);
		player.printSquaresUptoLimit();

		player.printSquaresUptoLimit();
		player.printCubesUptoLimit();
	}
}
