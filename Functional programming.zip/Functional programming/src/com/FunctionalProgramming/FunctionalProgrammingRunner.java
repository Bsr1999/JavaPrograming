package com.FunctionalProgramming;

import java.util.List;

public class FunctionalProgrammingRunner {

	public static void main(String[] args) {
		List<String>list =List.of("Apple","Banana","Dog","Bat","Cat");
		printWithFpWithFiltering (list);

	}

	private static void printBasic(List<String> list) {
		for(String str:list) {
			System.out.println(str);
		}
	}
	private static void printBasicWithFilter(List<String> list) {
		for(String str:list) {
			if(str.endsWith("at")) {
			System.out.println(str);
		}
	}
	}
	private static void printWithFp(List<String> list) {
	list.stream().forEach(element-> System.out.println("element- " + element));
	}
	private static void printWithFpWithFiltering(List<String> list) {
		list.stream()
		.filter(element ->element.endsWith("og"))
		.forEach(element-> System.out.println("element- " + element));
		}

}
