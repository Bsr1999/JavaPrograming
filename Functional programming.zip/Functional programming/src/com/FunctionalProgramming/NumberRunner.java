package com.FunctionalProgramming;

import java.util.List;

public class NumberRunner {

	public static void main(String[] args) {
		List<Integer> list=List.of(1,2,3,4,5,6,8);
		printNumbers(list);
	

	}

	private static void printNumbers(List<Integer> list) {
	list.stream()
	.filter(element -> element%2==0)
	.forEach(element-> 
	System.out.println(element));
		
	}

}
