package com.FunctionalProgramming;

import java.util.stream.IntStream;

public class numberSquares {

	public static void main(String[] args) {
		
		IntStream.range(1,111).map(e->e*e).forEach(e->System.out.println(e));
	
	}

}
