package com.FunctionalProgramming;

import java.util.List;

public class LowerCase {

	public static void main(String[] args) {
		List<String> words=List.of("Apple","Ant","Bat");
		words.stream().map(element->element.toLowerCase())
		.forEach(element->System.out.println(element));

	}

}
