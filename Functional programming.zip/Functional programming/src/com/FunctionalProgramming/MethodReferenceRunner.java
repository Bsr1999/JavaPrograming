package com.FunctionalProgramming;
import java.util.List;
public class MethodReferenceRunner {
	public static void print(Integer number) {
		System.out.println(number);
	}

	public static void main(String[] args) {
		List.of("Ant","Bat","Cat","Dog","Coin").stream()
		.map(s->s.length())
		.forEach(s-> MethodReferenceRunners.print(s));
		
		List.of("Ant","Bat","Cat","Dog","Bhanu").stream()
		.map(String::length)
		.forEach(System.out::println);
		
		Integer max=List.of(23,67,78,90,45).stream()
				.filter( MethodReferenceRunner :: isEven())
				.max(Integer :: compare)
				.orElse(0);
				System.out.println(max);
public static boolean isEven(Integer number) {
	return number%2==0;
	
}
}