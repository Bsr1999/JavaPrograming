package com.Bhanu.java.api.e;

import java.util.List;

public class TypeInteferenceRunner {

	public static void main(String[] args) {

List<String> names1=List.of("Ranga","Ravi");

List<String> names2=List.of("BHnau","Alia");

final var names=List.of(names1,names2);
names.stream().forEach(System.out::println);
for(var i=1;i<=10;i++)
	System.out.println(i);

	}

}
