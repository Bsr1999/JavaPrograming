package com.Bhanu.java.api.g;

public class TextBlockRunner {
	public static void main(String[] args) {
		String str="""
				*
				 ***
				  *****
				""";
		String textBook="""
				line1:%s
				line2:%s
				line3
				line4
				line5
				""".formatted("some Value" , "Some Other Value");
		System.out.print(textBook);	
					}
}
