package com.Bhanu.java.api.H;

public class RecordsRunner {
record Person(String name,String email,String phoneNumber) {
	Person{
		if(name==null)
			throw new IllegalArgumentException("name is null");
	}
	
}
	public static void main(String[] args) {
	Person person=new Person("Bhanu","sri@gmail.com","123-456-7890");
	System.out.println(person);

	}

}
