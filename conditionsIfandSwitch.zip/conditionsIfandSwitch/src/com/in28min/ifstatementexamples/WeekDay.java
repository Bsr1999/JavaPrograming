package com.in28min.ifstatementexamples;

public class WeekDay {

	public static void main(String[] args) {
		System.out.println(determineNameOfDay(0));

	}

	private static boolean determineNameOfDay(int weekday) {
		switch (weekday) {
		// case 0:
		// case 6:return false;
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
			return true;
		}
		// TODO Auto-generated method stub
		return false;
	}

}
