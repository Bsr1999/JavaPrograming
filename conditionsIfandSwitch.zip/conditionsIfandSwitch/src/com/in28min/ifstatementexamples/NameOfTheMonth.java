package com.in28min.ifstatementexamples;

public class NameOfTheMonth {

	public static void main(String[] args) {
		System.out.println(determineNameOfTheMonth(12));

	}

	private static String determineNameOfTheMonth(int monthNumber) {
		switch (monthNumber) {
		case 1:
			return "january";
		case 2:
			return "febrauary";
		case 3:
			return "March";
		case 4:
			return "April";
		case 5:
			return "May";
		case 6:
			return "june";
		case 7:
			return "july";
		case 8:
			return "august";
		case 9:
			return "september";
		case 10:
			return "october";
		case 11:
			return "november";
		case 12:
			return "december";
		}
		return "invalid";
	}

}
