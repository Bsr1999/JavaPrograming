package com.in28min.ifstatementexamples;

public class IfStatementRunner {
	public static void main(String[] args) {
		puzzle4();
		int i = 25;
		if (i == 25) {
			System.out.println("i=25");
		} else if (i == 24) {
			System.out.println("i=24");
		}

		else {
			System.out.println("!i=25");

		}
	}

	private static void puzzle3() {
		int m = 98;
		if (m < 20) {
			System.out.println("m>20");
		} else {
			System.out.println("who am i");
		}
	}

	private static void puzzle4() {
		int number = 9;
		if (number < 0) {
			number = number + 10;
		}
		number++;
		System.out.println(number);

	}

}
