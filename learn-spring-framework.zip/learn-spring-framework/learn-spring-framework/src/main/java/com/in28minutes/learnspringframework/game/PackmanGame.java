package com.in28minutes.learnspringframework.game;

public class PackmanGame implements GamingConsole{
	public void up() {
		System.out.println("fly");
	}
	public void down() {
		System.out.println("swim");
	}
	public void left() {
		System.out.println("run");
	}
	public void right() {
		System.out.println("jump");
	}

}
