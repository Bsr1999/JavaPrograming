package com.in28minutes.learnspringframework.game;

public class SuperContraGame implements GamingConsole {
	public void up() {
		System.out.println("up");
	}
	public void down() {
		System.out.println("Sit Down");
	}
	public void left() {
		System.out.println("come front");
	}
	public void right() {
		System.out.println("Fly");
	}

}
