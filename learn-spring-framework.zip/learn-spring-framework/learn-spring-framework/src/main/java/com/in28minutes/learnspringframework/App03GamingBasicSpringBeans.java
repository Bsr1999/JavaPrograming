package com.in28minutes.learnspringframework;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.in28minutes.learnspringframework.game.GameRunner;
import com.in28minutes.learnspringframework.game.GamingConsole;
import com.in28minutes.learnspringframework.game.MarioGame;
import com.in28minutes.learnspringframework.game.PackmanGame;
import com.in28minutes.learnspringframework.game.SuperContraGame;

public class App03GamingBasicSpringBeans {

	public static void main(String[] args) {
		try(	var context=new AnnotationConfigApplicationContext(GamingConfiguration.class);){

		
		
		context.getBean(GamingConsole.class).up();
		context.getBean(GameRunner.class).run();
		}
		//var game=new MarioGame();
		//var game=new SuperContraGame();
	// game=new PackmanGame();//1:object creation
      //  var gameRunner=new GameRunner(game);
//2: Object creation +Wring of Dependencies
        //Game is Dependency of GameRunner
//gameRunner.run();
	}

}
