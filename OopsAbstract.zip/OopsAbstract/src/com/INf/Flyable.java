package com.INf;

public interface Flyable {
	public void fly();

}
