package com.INf;

public class LudoGame  implements GamingConsole{

	@Override
	public void up() {
		System.out.println("Jump");
		
	}

	@Override
	public void down() {
		System.out.println("Go forward");
		
		
	}

	@Override
	public void left() {
		System.out.println("Slide");
		
		
	}

	@Override
	public void right() {
		System.out.println("Goes into a Hole");
		
		
	}

}
