package com.INf;

public interface ComplexAlgorithm {
	int complexAlgorithm(int number1,int number2);
	
	

}
