package com.INf;

public class Aeroplane implements Flyable {
	@Override
	public void fly() {
		System.out.println("Fly with fuel");
		
	}


}
