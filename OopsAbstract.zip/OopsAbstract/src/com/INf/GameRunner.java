package com.INf;

public class GameRunner {
	public static void main(String[] args) {
		GamingConsole[] games= {new LudoGame(),new ChessGame()};
		for(GamingConsole game:games) {
		//GamingConsole game=new LudoGame();
		game.up();
		game.down();
		game.right();
		game.left();
	}
	}
}
