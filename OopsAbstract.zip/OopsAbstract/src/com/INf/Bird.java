package com.INf;

public class Bird implements Flyable {
	public void fly() {
		System.out.println("Fly with wings");
		
	}


}
