package com.ABS;

public class RecipewithMicroWave extends AbstractRecipe {

	@Override
	void getReady() {
		System.out.println("get raw materials");
		System.out.println("Switch on");
		
		
	}

	@Override
	void doTheDish() {
	System.out.println("do the dish");
	System.out.println("put it in the microwave");
		
	}

	@Override
	void cleanup() {
		System.out.println("clean the utensils");
		System.out.println("Switch off");
	}

}
