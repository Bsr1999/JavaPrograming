package com.ABS;

public class Recipe1 extends AbstractRecipe {

	@Override
	void getReady() {
		System.out.println("get raw materials");
		System.out.println("get the utensiles");
		
		
	}

	@Override
	void doTheDish() {
	System.out.println("do the dish");
		
	}

	@Override
	void cleanup() {
		System.out.println("clean the utensils");
		
	}

}
