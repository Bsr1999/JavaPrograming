package com.ABS;

public class RecipeRunner {
	public static void main(String[] args) {
		Recipe1 recipe=new Recipe1();
		recipe.execute();
		RecipewithMicroWave recipewithMicroWave=new RecipewithMicroWave();
		recipewithMicroWave.execute();
	}

}
