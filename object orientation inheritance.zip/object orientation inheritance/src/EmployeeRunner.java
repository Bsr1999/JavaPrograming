
public class EmployeeRunner {

	public static void main(String[] args) {
		
	/*Person person=new Person();
		
	Person person=new Person();
		person.setName("BHANU");
		person.setEmail("sri@gmail.com");
		person.setPhoneNumber("945637829");
		String value=person.toString();
		System.out.println(value);
		System.out.println(person);*/
	
		
		 Employee employee=new Employee("Ranga", "Programmer Analyst");
			employee.setName("Bhanu");
			employee.setEmail("sri@gmail.com");
			employee.setEmployeeGrade('A');
			employee.setTitle("Programmer Analyst");
	System.out.print(employee);}

}
