

public class Student extends Person {
	public Student(String name,String collegeName) {
		super(name);
		this.collegeName=collegeName;
		// TODO Auto-generated constructor stub
	}
	private String collegeName;
	private int year;
	public String getCollegeNmae() {
		return collegeName;
	}
	public void setCollegeNmae(String collegeNmae) {
		this.collegeName = collegeNmae;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	

}
