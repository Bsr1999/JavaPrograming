

public class StudentRunner {
	public static void main(String[] args) {
		
	
//Student student=new Student();
//student.setName("Bhanu");
//student.setEmail("sri@gmail.com");

Person person=new Person("Bhanu");
person.setName("BHANU");
person.setEmail("sri@gmail.com");
person.setPhoneNumber("945637829");
String value=person.toString();
System.out.println(value);
System.out.println(person);

	}
}
