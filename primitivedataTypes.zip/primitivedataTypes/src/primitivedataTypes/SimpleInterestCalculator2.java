package primitivedataTypes;

import java.math.BigDecimal;

public class SimpleInterestCalculator2 {
	public static void main(String[] args) {
		SimpleInterestCalculator calculator = new SimpleInterestCalculator("4500.00", "7.5");
		BigDecimal totalValue = calculator.calculateTotalValue(5);// 5 years
		System.out.println(totalValue);
	}
}
